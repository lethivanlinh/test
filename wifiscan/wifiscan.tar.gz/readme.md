This is README.md file
Github link: https://github.com/lethivanlinh/test/tree/master/wifiscan
Include files: main.c makefile wifiscan.c wifiscan.h 
Information:
Scan wifi around and publish the information to scan.txt
